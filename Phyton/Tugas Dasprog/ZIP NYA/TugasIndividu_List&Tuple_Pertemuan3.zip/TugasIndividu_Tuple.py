# Nama      : Zaky Rizzan Zain
# NIM       : 2403342
# Kelas     : Kelas 1B
# Matkul    : Daspro


# Tuple Daftar Pasangan (Latitude, Logitude) Lokasi
Jakarta = (-6.2088, 106.8456)
Bandung = (-6.9175, 107.6191)
Surabaya = (-7.2575, 112.7521)

Data_List = [Jakarta, Bandung, Surabaya]

# Data Koordinat Bandung
print(Data_List[1])


# Jumlah Lokasi Tersimpan
print(len(Data_List))



