# Nama      : Zaky Rizzan Zain
# NIM       : 2403342
# Kelas     : Kelas 1B
# Matkul    : Daspro

list = ["Apel", "Jeruk", "Ceri", "Durian","Apel", "Mangga"]


# No 1
list[2]="Cherry"
print(list)


# No 2
No_Index = (int(input(f"Masukkan No Index Yang Ingin Ditambahkan : ")))
Nama_Item = input("Masukkan Nama Item Yang Ingin Ditambahkan :  ")
list.insert(No_Index,Nama_Item)
print(list)

# No 3
list.sort()
print(list)

