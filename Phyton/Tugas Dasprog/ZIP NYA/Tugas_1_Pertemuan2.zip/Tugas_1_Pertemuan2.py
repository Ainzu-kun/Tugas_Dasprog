# Nama      : Zaky Rizzan Zain
# NIM       : 2403342
# Kelas     : RPL 1B

Nama = input("Masukkan Nama Anda :  ")
Umur = input("Masukkan Umur Anda :  ")

print(f"Selamat datang {Nama}, umur kamu adalah {Umur} tahun")

