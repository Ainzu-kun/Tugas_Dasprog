# Nama      : Zaky Rizzan Zain
# NIM       : 2403342
# Kelas     : RPL 1B

Nama = input("Masukkan Nama Anda :  ")
tahun_lahir = int(input("Masukkan Tahun Lahir Anda : "))
Umur = 2024 - tahun_lahir

print(f"Selamat datang {Nama}, umur kamu adalah {Umur} tahun")
