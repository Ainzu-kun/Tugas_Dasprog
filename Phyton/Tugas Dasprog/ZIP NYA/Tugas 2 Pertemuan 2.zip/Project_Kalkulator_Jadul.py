# Nama      : Ainz Sama
# NIM       : 2403342
# Kelas     : RPL 1B
# Matkul    : Dasar Pemrograman

print("Program Kalkulator Jadul")
a = int(input("Masukkan Bilangan Ke-1 : "))
b = int(input("Masukkan Bilangan Ke-1 : "))
c = int(input("Masukkan Bilangan Ke-1 : "))

hasil = a + b + c
print(f"Hasil dari penjumlahan {a} + {b} + {c} adalah = {hasil}")



