# Nama      : Zaky Rizzan Zain
# NIM       : 2403342
# Kelas     : RPL 1B

print("Mencari Luas Segitiga")
alas = int(input("Masukkan Alas Segitiga : "))
tinggi = int(input("Masukkan Tinggi Segitiga : "))


# Bisa Pake Float untuk hasil desimal
# alas = float(int(input("Masukkan Alas Segitiga : "))
# tinggi = float(int(input("Masukkan Tinggi Segitiga : "))

Hasil = 1/2 * alas * tinggi
print(Hasil)
