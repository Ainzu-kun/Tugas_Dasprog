# Nama      : Zaky Rizzan Zain
# NIM       : 2403342
# Kelas     : Kelas 1B
# Matkul    : Daspro

# Input = [10,20,20,30,40,50,50,60]
# Output = [10,20,30,40,50,60]

Nomor = [10,20,20,30,40,50,50,60]
Set_Nomor = set(Nomor)
List = list(Set_Nomor)
List.sort()
print(List)

